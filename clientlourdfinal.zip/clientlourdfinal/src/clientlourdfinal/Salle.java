package clientlourdfinal;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.sql.*;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;


public class Salle extends JFrame {

	private JButton btnDigicode;
	private JPanel contentPane;
	private String roomSelected;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Salle frame = new Salle();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Salle() {
		initWindow();
	}

	private void initWindow()	{
		initComposants();
		initEvents();
	}
	
	private void initComposants()	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		//
		// decla des compos
		textField = new JTextField();
		List list = new List();
		contentPane.add(list, BorderLayout.CENTER);
		
		

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connexion = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/m2l?useSSL=false", "root", "root");
			
			String query3 = "SELECT Salle, Section FROM booking ORDER BY Salle";
			Statement st3 = connexion.createStatement();
			ResultSet res3 = st3.executeQuery(query3);
			
			while(res3.next()) {
				String room = res3.getString("Salle");
				String sect = res3.getString("Section");
				String total = "Salle : " + room + " Section : " + sect;
				
				list.add(total);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		JButton btnDigicode = new JButton("R\u00E9cuperer digicode");
		btnDigicode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					for (int i = 0; i < list.getItemCount(); i++) {
						if(list.isIndexSelected(i))	{
							roomSelected = list.getItem(i);
						}
					}
				String[] ephemere = roomSelected.split(" ");
				roomSelected = ephemere[2];
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection connexion = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/m2l?useSSL=false", "root", "root");
					String query4 = "SELECT digicode FROM booking WHERE Salle=?";
					PreparedStatement st4 = connexion.prepareStatement(query4);
					st4.setString(1, roomSelected);
					ResultSet res4 = st4.executeQuery();
					
					if(res4.next())	{
						textField.setText(res4.getString(1));
					}
					
					
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
			}
		});
		contentPane.add(btnDigicode, BorderLayout.SOUTH);
		
		
		textField.setText("??");
		contentPane.add(textField, BorderLayout.EAST);
		textField.setColumns(10);
		
	}
	
	
	private void initEvents()	{
		
	}
}
