package clientlourdfinal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Connexion {

	public void Connexion() {
		
		final String driver = "com.mysql.jdbc.Driver";
		final String url = "jdbc:mysql://localhost/m2l";
		final String user = "root";
		final String password = "root";
		
		String query = "select * from booking";
		ResultSet res;
		
		try {
			Class.forName(driver).newInstance();
			Connection con = DriverManager.getConnection(url,user,password);
			Statement st = con.createStatement();
			res = st.executeQuery(query);
		} catch(Exception e){
			System.out.println("Classe non trouv�e " + driver);
		}
		

	
	}
}