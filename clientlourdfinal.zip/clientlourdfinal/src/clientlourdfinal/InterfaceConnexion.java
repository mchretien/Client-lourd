package clientlourdfinal;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class InterfaceConnexion extends JFrame {
	private JTextField login;
	private JTextField mdp;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfaceConnexion frame = new InterfaceConnexion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterfaceConnexion() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		login = new JTextField();
		login.setBounds(161, 71, 86, 20);
		getContentPane().add(login);
		login.setColumns(10);
		
		mdp = new JTextField();
		mdp.setBounds(161, 115, 86, 20);
		getContentPane().add(mdp);
		mdp.setColumns(10);
		
		JLabel lblLogin = new JLabel("login");
		lblLogin.setBounds(105, 74, 46, 14);
		getContentPane().add(lblLogin);
		
		JLabel lblMdp = new JLabel("mdp");
		lblMdp.setBounds(105, 118, 46, 14);
		getContentPane().add(lblMdp);
		
		JButton btnConnexion = new JButton("Connexion");
		btnConnexion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try	{
					Class.forName("com.mysql.jdbc.Driver");
					Connection connexion = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/m2l?useSSL=false", "root", "root");
					String loginS=login.getText();
					String mdpS=mdp.getText();
					
					String query2 = "SELECT * FROM users WHERE pseudo=? AND password=?";
					ResultSet res2;
					PreparedStatement st2 = connexion.prepareStatement(query2);
					st2.setString(1, loginS);
					st2.setString(2, mdpS);
					res2 = st2.executeQuery();
					
				if(res2.next())	{
					dispose();
					Salle salle = new Salle();
					salle.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "connexion pas ok");
				}
				} catch (ClassNotFoundException | SQLException e)	{
					e.printStackTrace();
					
				}
			}
		});
		btnConnexion.setBounds(161, 165, 89, 23);
		getContentPane().add(btnConnexion);
		
		
		
	}
}
